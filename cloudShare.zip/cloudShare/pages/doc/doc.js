Page({
  onLaunch: function (option) {
   console.log(option.id)

  }
})